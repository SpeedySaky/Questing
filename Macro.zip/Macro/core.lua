
local loadingFrame = CreateFrame("Frame");

loadingFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
loadingFrame:SetScript("OnEvent",function()
englishFaction, localizedFaction = UnitFactionGroup("player")
race = UnitRace("player")
level = UnitLevel("player")





local macroIndex = GetMacroIndexByName("Gossip2")
if macroIndex == 0  then --Gossip2
  local macroId = CreateMacro("Gossip2", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(2);", nil);

end




local macroIndex = GetMacroIndexByName("Hearthstone")
if macroIndex == 0  then--Hearthstone
  local macroId = CreateMacro("Hearthstone", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(1);\n/script C_PlayerInteractionManager.ConfirmationInteraction(Enum.PlayerInteractionType.Binder)", nil);

end

local macroIndex = GetMacroIndexByName("Hearthstone2")
if macroIndex == 0  then
  local macroId = CreateMacro("Hearthstone2", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(2);\n/script C_PlayerInteractionManager.ConfirmationInteraction(Enum.PlayerInteractionType.Binder)", nil);

end

local macroIndex = GetMacroIndexByName("Hearthstone3")
if macroIndex == 0  then
  local macroId = CreateMacro("Hearthstone3", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(3);\n/script C_PlayerInteractionManager.ConfirmationInteraction(Enum.PlayerInteractionType.Binder)", nil);

end


local macroIndex = GetMacroIndexByName("Rhapsody")
if macroIndex == 0 and  race == "Dwarf" or race == "Gnome" and level<10 then
  local macroId = CreateMacro("Rhapsody", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(2);\n/run BuyMerchantItem(1)", nil);
	else
		if race == "Dwarf" or race == "Gnome" and level>=10 then
		local macroId = DeleteMacro("Rhapsody");
		end
end
--dwarf/gnome
local macroIndex = GetMacroIndexByName("ThunderAle")
if macroIndex == 0 and race == "Dwarf" or race == "Gnome" and level<10 then
  local macroId = CreateMacro("ThunderAle", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(2);\n/run BuyMerchantItem(2)", nil);
	else
		if race == "Dwarf" or race == "Gnome" and level>=10 then
		local macroId = DeleteMacro("ThunderAle");
		end
	end


--FP Eastern Kingdoms-Alliance

local macroIndex = GetMacroIndexByName("Ironforge")
if macroIndex == 0 and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race =="Draenei" then
  local macroId = CreateMacro("Ironforge", "INV_MISC_QUESTIONMARK", "/run local n=\"Ironforge\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);

end
local macroIndex = GetMacroIndexByName("Thelsamar")
if macroIndex == 0 and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race =="Draenei"  and level<=20 then
  local macroId = CreateMacro("Thelsamar", "INV_MISC_QUESTIONMARK", "/run local n=\"Thelsamar\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
  else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>20 then
		local macroId = DeleteMacro("Thelsamar");
		end

end

local macroIndex = GetMacroIndexByName("Stormwind")
if macroIndex == 0 and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" then
  local macroId = CreateMacro("Stormwind", "INV_MISC_QUESTIONMARK", "/run local n=\"Stormwind\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);

end

local macroIndex = GetMacroIndexByName("Lakeshire")
if macroIndex == 0 and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level<30 then
  local macroId = CreateMacro("Lakeshire", "INV_MISC_QUESTIONMARK", "/run local n=\"Lakeshire\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
   else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 then
		local macroId = DeleteMacro("Lakeshire");
		end

end

local macroIndex = GetMacroIndexByName("Sentinel Hill")
if macroIndex == 0 and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level<=30 then
  local macroId = CreateMacro("Sentinel Hill", "INV_MISC_QUESTIONMARK", "/run local n=\"Sentinel Hill\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
  else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 then
		local macroId = DeleteMacro("Sentinel Hill");
		end

end

local macroIndex = GetMacroIndexByName("Booty Bay")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 and level<40 then
  local macroId = CreateMacro("Booty Bay", "INV_MISC_QUESTIONMARK", "/run local n=\"Booty Bay\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>40 then
		local macroId = DeleteMacro("Booty Bay");
		end
end

local macroIndex = GetMacroIndexByName("Chillwind Camp")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level >45 and level<60 then
  local macroId = CreateMacro("Chillwind Camp", "INV_MISC_QUESTIONMARK", "/run local n=\"Chillwind Camp\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>60 then
		local macroId = DeleteMacro("Chillwind Camp");
		end
end

local macroIndex = GetMacroIndexByName("Refuge Pointe")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level >30 and level<45 then
  local macroId = CreateMacro("Refuge Pointe", "INV_MISC_QUESTIONMARK", "/run local n=\"Refuge Pointe\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>45 then
		local macroId = DeleteMacro("Refuge Pointe");
		end
end

local macroIndex = GetMacroIndexByName("Menethil Harbor")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level >20 and level<45 then
  local macroId = CreateMacro("Menethil Harbor", "INV_MISC_QUESTIONMARK", "/run local n=\"Menethil Harbor\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>45 then
		local macroId = DeleteMacro("Menethil Harbor");
		end
end

local macroIndex = GetMacroIndexByName("Southshore")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level >20 and level<40 then
  local macroId = CreateMacro("Southshore", "INV_MISC_QUESTIONMARK", "/run local n=\"Southshore\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>40 then
		local macroId = DeleteMacro("Southshore");
		end
end

local macroIndex = GetMacroIndexByName("Darkshire")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level >20 and level<40 then
  local macroId = CreateMacro("Darkshire", "INV_MISC_QUESTIONMARK", "/run local n=\"Darkshire\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>40 then
		local macroId = DeleteMacro("Darkshire");
		end
end

local macroIndex = GetMacroIndexByName("Morgan's Vigil")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level >50 and level<60 then
  local macroId = CreateMacro("Morgan's Vigil", "INV_MISC_QUESTIONMARK", "/run local n=\"Morgan's Vigil\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>60 then
		local macroId = DeleteMacro("Morgan's Vigil");
		end
end
local macroIndex = GetMacroIndexByName("Thorium Point")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level >40 and level<55 then
  local macroId = CreateMacro("Thorium Point", "INV_MISC_QUESTIONMARK", "/run local n=\"Thorium Point\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>55 then
		local macroId = DeleteMacro("Thorium Point");
		end
end

local macroIndex = GetMacroIndexByName("Aerie Peak")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level >40 and level<55 then
  local macroId = CreateMacro("Aerie Peak", "INV_MISC_QUESTIONMARK", "/run local n=\"Aerie Peak\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>50 then
		local macroId = DeleteMacro("Aerie Peak");
		end
end



--FP Kalimdor-Alliance

local macroIndex = GetMacroIndexByName("Rut'theran Village")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race=="Draenei" and level<60 then
  local macroId = CreateMacro("Rut'theran Village", "INV_MISC_QUESTIONMARK", "/run local n=\"Rut'theran Village\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>60 then
		local macroId = DeleteMacro("Rut'theran Village");
		end
end


local macroIndex = GetMacroIndexByName("Auberdine")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>10 and level<20 then
  local macroId = CreateMacro("Auberdine", "INV_MISC_QUESTIONMARK", "/run local n=\"Auberdine\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>20 then
		local macroId = DeleteMacro("Auberdine");
		end
end

local macroIndex = GetMacroIndexByName("Astranaar")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>20 and level<30 then
  local macroId = CreateMacro("Astranaar", "INV_MISC_QUESTIONMARK", "/run local n=\"Astranaar\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 then
		local macroId = DeleteMacro("Astranaar");
		end
end

local macroIndex = GetMacroIndexByName("Stonetalon Peak")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>20 and level<30 then
  local macroId = CreateMacro("Stonetalon Peak", "INV_MISC_QUESTIONMARK", "/run local n=\"Stonetalon Peak\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 then
		local macroId = DeleteMacro("Stonetalon Peak");
		end
end

local macroIndex = GetMacroIndexByName("Nijel's Point")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 and level<40 then
  local macroId = CreateMacro("Nijel's Point", "INV_MISC_QUESTIONMARK", "/run local n=\"Nijel's Point\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>40 then
		local macroId = DeleteMacro("Nijel's Point");
		end
end

local macroIndex = GetMacroIndexByName("Forest Song")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>20 and level<30 then
  local macroId = CreateMacro("Forest Song", "INV_MISC_QUESTIONMARK", "/run local n=\"Forest Song\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 then
		local macroId = DeleteMacro("Forest Song");
		end
end

local macroIndex = GetMacroIndexByName("Theramore Isle")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 and level<50 then
  local macroId = CreateMacro("Theramore Isle", "INV_MISC_QUESTIONMARK", "/run local n=\"Theramore Isle\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 then
		local macroId = DeleteMacro("Theramore Isle");
		end
end

local macroIndex = GetMacroIndexByName("Ratchet")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>20 and level<35 then
  local macroId = CreateMacro("Ratchet", "INV_MISC_QUESTIONMARK", "/run local n=\"Ratchet\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>30 then
		local macroId = DeleteMacro("Ratchet");
		end
end

local macroIndex = GetMacroIndexByName("Talendris Point")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>40 and level<55 then
  local macroId = CreateMacro("Talendris Point", "INV_MISC_QUESTIONMARK", "/run local n=\"Talendris Point\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>55 then
		local macroId = DeleteMacro("Talendris Point");
		end
end

local macroIndex = GetMacroIndexByName("Talonbranch Glade")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>45 and level<55 then
  local macroId = CreateMacro("Talonbranch Glade", "INV_MISC_QUESTIONMARK", "/run local n=\"Talonbranch Glade\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>55 then
		local macroId = DeleteMacro("Talonbranch Glade");
		end
end

local macroIndex = GetMacroIndexByName("Everlook")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>50 and level<60 then
  local macroId = CreateMacro("Everlook", "INV_MISC_QUESTIONMARK", "/run local n=\"Everlook\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>60 then
		local macroId = DeleteMacro("Everlook");
		end
end

local macroIndex = GetMacroIndexByName("Cenarion Hold")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>55 and level<60 then
  local macroId = CreateMacro("Cenarion Hold", "INV_MISC_QUESTIONMARK", "/run local n=\"Cenarion Hold\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>60 then
		local macroId = DeleteMacro("Cenarion Hold");
		end
end

local macroIndex = GetMacroIndexByName("Marshal's Refugee")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>45 and level<55 then
  local macroId = CreateMacro("Marshal's Refugee", "INV_MISC_QUESTIONMARK", "/run local n=\"Marshal's Refugee\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>55 then
		local macroId = DeleteMacro("Marshal's Refugee");
		end
end

local macroIndex = GetMacroIndexByName("Gadgetzan")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>45 and level<55 then
  local macroId = CreateMacro("Gadgetzan", "INV_MISC_QUESTIONMARK", "/run local n=\"Gadgetzan\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>55 then
		local macroId = DeleteMacro("Gadgetzan");
		end
end

local macroIndex = GetMacroIndexByName("Thalanaar")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>40 and level<50 then
  local macroId = CreateMacro("Thalanaar", "INV_MISC_QUESTIONMARK", "/run local n=\"Thalanaar\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>50 then
		local macroId = DeleteMacro("Thalanaar");
		end
end

local macroIndex = GetMacroIndexByName("Feathermoon Stronghold")
if macroIndex == 0 and race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>40 and level<50 then
  local macroId = CreateMacro("Feathermoon Stronghold", "INV_MISC_QUESTIONMARK", "/run local n=\"Feathermoon Stronghold\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if race == "Dwarf" and race == "Human" or race == "Dwarf" or race == "Gnome" or race== "Night Elf" or race== "Draenei" and level>50 then
		local macroId = DeleteMacro("Feathermoon Stronghold");
		end
end

local macroIndex = GetMacroIndexByName("Exodar")
if macroIndex == 0 and race== "Draenei" and level>10 and level<20 then
  local macroId = CreateMacro("Exodar", "INV_MISC_QUESTIONMARK", "/run local n=\"Exodar\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if  race== "Draenei" and level>20 then
		local macroId = DeleteMacro("Exodar");
		end
end

local macroIndex = GetMacroIndexByName("Blood Watch")
if macroIndex == 0 and race== "Draenei" and level>10 and level<20 then
  local macroId = CreateMacro("Blood Watch", "INV_MISC_QUESTIONMARK", "/run local n=\"Blood Watch\"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G[\"TaxiButton\"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end;", nil);
else
		if  race== "Draenei" and level>20 then
		local macroId = DeleteMacro("Blood Watch");
		end
end


--FP Kalimdor-Horde


end);






-----------------------------


--/run local n = "Ironforge"; for i=1, NUM_TAXI_BUTTONS do if TaxiNodeName(_G["TaxiButton"..i]:GetID()):lower():find(n:lower()) then TakeTaxiNode(i) return; end end PlaySound(47355);
