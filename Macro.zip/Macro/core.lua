local loadingFrame = CreateFrame("Frame");
loadingFrame:RegisterEvent("PLAYER_ENTERING_WORLD");
loadingFrame:SetScript("OnEvent",function()


local macroIndex = GetMacroIndexByName("Hearthstone")
if macroIndex == 0 then
  local macroId = CreateMacro("Hearthstone", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(1);\n/script ConfirmBinder()", nil);

end

local macroIndex = GetMacroIndexByName("Rhapsody")
if macroIndex == 0 then
  local macroId = CreateMacro("Rhapsody", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(2);\n/run BuyMerchantItem(1)", nil);

end

local macroIndex = GetMacroIndexByName("ThunderAle")
if macroIndex == 0 then
  local macroId = CreateMacro("ThunderAle", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(2);\n/run BuyMerchantItem(2)", nil);

end

local macroIndex = GetMacroIndexByName("IF")
if macroIndex == 0 then
  local macroId = CreateMacro("IF", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(1);\n/script numNodes = NumTaxiNodes();\n/script TakeTaxiNode(1)", nil);

end
local macroIndex = GetMacroIndexByName("Thelsamar")
if macroIndex == 0 then
  local macroId = CreateMacro("Thelsamar", "INV_MISC_QUESTIONMARK", "/script SelectGossipOption(1);\n/script numNodes = NumTaxiNodes();\n/script TakeTaxiNode(2)", nil);

end



end);


-----------------------------

